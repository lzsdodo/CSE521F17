#ifndef USERPROG_PROCESS_H
#define USERPROG_PROCESS_H

#include "threads/thread.h"

tid_t process_execute (const char *file_name);
static void start_process (void *file_name_);
int process_wait (tid_t);
void process_exit (void);
void process_activate (void);

static bool argument_passing(void **esp, char *file_name);
static bool load (const char *cmdline, void (**eip) (void), void **esp);
static bool setup_stack (void **esp);
static bool install_page (void *upage, void *kpage, bool writable);

static struct p_info* look_up_child_thread(tid_t child_tid);
static struct list_elem* look_up_elem(tid_t child_tid);
void close_all_process(struct list* child_process);
void close_all_files(struct list* process_files);
struct info_p* get_current_process(void);

#endif /* userprog/process.h */
