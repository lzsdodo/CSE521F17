# CSE421/521 Assignment3
This repository has an initial setting to start assignment 3.

Direction
---------
* Go to __pintos__ directory.
* Remove __src__ directory with sudo command __(password: cse421521)__
```sh
$ cd ~/pintos
$ sudo rm -r src
```
* Clone your repository. 
(The link is at upper-right corner, choose http if you didn't set up ssh-key)    
```sh
$ git clone [repository-link]
```

Etc.
----
* We strongly recommend you to remove whole __src__ folder and clone it unless you already have written a lot of code.
* [This link](https://help.github.com/articles/connecting-to-github-with-ssh/) is for SSH setup.
